# Connectors_Powerpole.pretty
Anderson Powerpole footprints for Kicad
